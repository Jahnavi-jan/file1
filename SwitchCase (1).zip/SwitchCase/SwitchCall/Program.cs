﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SwitchCase;

namespace SwitchCall
{
    class Program
    {
        static void Main(string[] args)
        {
            Switch s = new Switch();
            Console.Write("Enter Your Choice Between 1 to 5 : ");
            int choice = Convert.ToInt32(Console.ReadLine());
            s.SwitchCall(choice);
            Console.ReadKey();
        }
    }
}
