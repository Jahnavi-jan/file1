﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwitchCase
{
    public class Switch
    {
        public void SwitchCall(int choice)
        {
            switch(choice)
            {
                case 1:
                    Console.WriteLine("You Enter 1");
                    break;
                case 2:
                    Console.WriteLine("You Enter 2");
                    break;
                case 3:
                    Console.WriteLine("You Enter 3");
                    break;
                case 4:
                    Console.WriteLine("You Enter 4");
                    break;
                case 5:
                    Console.WriteLine("You Enter 5");
                    break;
                default:
                    Console.WriteLine("You Enter Another Number");
                    break;
            } 
        }
    }
}
